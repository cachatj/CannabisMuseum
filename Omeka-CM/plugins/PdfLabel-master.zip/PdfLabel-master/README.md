# PdfLabel
TCPDF Class to print labels in Avery or custom formats

Based on work of Laurent PASSEBECQ <lpasseb@numericable.fr>
