<?php

/**
 * Thrown by OaipmhHarvester_Request_Throttler to block excessive requests.
 *
 * @package OaipmhHarvester
 */
class OaipmhHarvester_Request_ThrottlerException extends Exception
{}
